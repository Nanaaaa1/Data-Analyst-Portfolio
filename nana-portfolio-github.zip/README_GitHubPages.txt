# Nana Adu-Abankro — Data Analyst Portfolio and Insights

This is a single-file portfolio site. Deploy it on GitHub Pages:

1) Create a new public repo on GitHub (e.g., `nana-portfolio`).
2) Upload `index.html` to the root of the repo and commit.
3) Go to Settings → Pages → set Source = Deploy from a branch, Branch = main, Folder = /(root).
4) Save, wait ~1–2 minutes, then open: https://<your-username>.github.io/nana-portfolio/

Updating your Tableau link:
- Open `index.html` and find the line that starts with `tableauSrc:`.
- Replace the URL with your Tableau Public embed link.
- Commit the change to update the live site.
